library(readxl)
library(neuralnet)
library(Metrics)
library(MLmetrics)
library(mlbench)

#Loading the data set and creating the data Frame.
dataFrame <- read_excel("C://Users//LENOVO//Documents//ML CW//uow_consumption.xlsx")
str(dataFrame)
dataFrame <- subset(dataFrame, select = -1)
col_names <- names(dataFrame)

par(mar=c(5, 5, 2, 1), oma = c(0, 0, 2, 0), cex = 1.2, cex.lab = 1.2, cex.axis = 1.2)
par(bg = "lightgray")
par(mfrow = c(1, 3))

# set custom colors for the box and whiskers
box_col <- "#0072B2"
whisker_col <- "#E69F00"

for (i in seq_len(ncol(dataFrame))){
  boxplot(dataFrame[i],
          col = box_col,
          border = box_col,
          whisklty = 1,
          whiskcol = whisker_col,
          ylab = "Value",
          xlab = "",
          cex.main = 1.5,
          cex.lab = 1.2,
          cex.axis = 1.2)
}


columns <- c("Day1","Day2","Day3","Day4", "NextDay")

# pass this vector length to ncol parameter
# and nrow with 0
DataFrame_days <- data.frame(matrix(nrow = 0, ncol = length(columns)))

# assign column names
colnames(DataFrame_days) <- columns


i <- 1
while(i<497){
  values <- data.frame(dataFrame$Time20[i], dataFrame$Time20[i+1], dataFrame$Time20[i+2],dataFrame$Time20[i+3],dataFrame$Time20[i+4])
  #Naming the Data Frame - Step 2
  names(values) <- c("Day1","Day2","Day3","Day4", "NextDay")
  DataFrame_days <- rbind(DataFrame_days, values)
  i <- i + 1
}

str(DataFrame_days)
write.csv(DataFrame_days, "test_DataFrame_AR(4).csv")
 #---------------------------------------perform scaling-----------------------------#

# Define a function to normalize data
normalize <- function(x) {
  return((x - min(x)) / (max(x) - min(x)))
}

# Load the data and remove missing values
data <- read.csv("test_DataFrame_AR(4).csv")
data <- na.omit(data)[-1]

# Split the data into training and testing sets
train_idx <- round(0.8 * nrow(data))
train_data <- data[1:train_idx,]
test_data <- data[train_idx:nrow(data),]

# Normalize the data
train_data_norm <- data.frame(lapply(train_data, normalize))
test_data_norm <- data.frame(lapply(test_data, normalize))

# Build the neural network model
set.seed(4444)
nn <- neuralnet(NextDay ~ ., data = train_data_norm, hidden = c(5),
                learningrate = 0.0001, act.fct = "logistic", linear.output = TRUE)
plot(nn)
# Make predictions on the test set
test_input <- as.data.frame(test_data_norm[, -ncol(test_data_norm)])
nn_results <- compute(nn, test_input)

# Denormalize the predictions and actual values
test_output <- test_data$NextDay
pred_output <- nn_results$net.result * (max(test_output) - min(test_output)) + min(test_output)

sMAPE <- function(pred, actual) {
  mean(2 * abs(pred - actual) / (abs(pred) + abs(actual))) * 100
}
# Define a function to calculate performance metrics
calc_metrics <- function(actual, pred) {
  rmse <- rmse(pred, actual)
  mae <- mae(pred, actual)
  mape <- MAPE(pred, actual)
  smape <- sMAPE(pred, actual)
  return(list(RMSE = rmse, MAE = mae, MAPE = mape, sMAPE = smape))
}

# Calculate and print the performance metrics
metrics <- calc_metrics(test_output, pred_output)
print(metrics)
