library(readxl)

#Loading the data set and creating the data Frame.
dataFrame <- read_excel("C://Users//LENOVO//Documents//ML CW//uow_consumption.xlsx")

#"Day2_9","Day2_10","Day2_11", ,"Day4_9","Day4_10","Day4_11",
columns= c("Day1_18","Day1_19","Day1_20","Day2_18","Day2_19","Day2_20","Day3_18","Day3_19","Day3_20","Day4_18","Day4_19","Day4_20","NextDay_18","NextDay_19","NextDay_20")

# pass this vector length to ncol parameter
# and nrow with 0
DataFrame_days = data.frame(matrix(nrow = 0, ncol = length(columns)))

# assign column names
colnames(DataFrame_days) = columns

#, dataFrame$Time9[i+2], dataFrame$Time10[i+2], dataFrame$Time11[i+2], dataFrame$Time9[i+3], dataFrame$Time10[i+3], dataFrame$Time11[i+3], dataFrame$Time9[i+4], dataFrame$Time10[i+4], dataFrame$Time11[i+4]
i <- 1
while(i<500){
  values <- data.frame(dataFrame$Time18[i], dataFrame$Time19[i], dataFrame$Time20[i], 
                       dataFrame$Time18[i+1], dataFrame$Time19[i+1], dataFrame$Time20[i+1],
                       dataFrame$Time18[i+2], dataFrame$Time19[i+2], dataFrame$Time20[i+2],
                       dataFrame$Time18[i+3], dataFrame$Time19[i+3], dataFrame$Time20[i+3],
                      dataFrame$Time18[i+4], dataFrame$Time19[i+4], dataFrame$Time20[i+4])
  #Naming the Data Frame - Step 2
  names(values) <- c("Day1_18","Day1_19","Day1_20","Day2_18","Day2_19","Day2_20","Day3_18","Day3_19","Day3_20","Day4_18","Day4_19","Day4_20","NextDay_18","NextDay_19","NextDay_20")
  DataFrame_days <- rbind(DataFrame_days, values)
  i = i +1
}

str(DataFrame_days)
write.csv(DataFrame_days, "test_DataFrame_NARX(4).csv")

#----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

# Define a function to normalize data
normalize <- function(x) {
  return((x - min(x)) / (max(x) - min(x)))
}

# Load the data and remove missing values
data <- read.csv("test_DataFrame_NARX(2).csv")
data <- na.omit(data)[-1]

# Split the data into training and testing sets
train_idx <- round(0.8 * nrow(data))
train_data <- data[1:train_idx,]
test_data <- data[train_idx:nrow(data),]

# Normalize the data
train_data_norm <- data.frame(lapply(train_data, normalize))
test_data_norm <- data.frame(lapply(test_data, normalize))

# Build the neural network model
set.seed(4444)
nn <- neuralnet(NextDay_20 ~., data = train_data_norm, hidden = c(11, 8),
                learningrate = 0.0001, act.fct = "tanh", linear.output = TRUE)
plot(nn)
# Make predictions on the test set
test_input <- as.data.frame(test_data_norm[, -ncol(test_data_norm)])
nn_results <- compute(nn, test_input)

# Denormalize the predictions and actual values
test_output <- test_data$NextDay_20
pred_output <- nn_results$net.result * (max(test_output) - min(test_output)) + min(test_output)

sMAPE <- function(pred, actual) {
  mean(2 * abs(pred - actual) / (abs(pred) + abs(actual))) * 100
}
# Define a function to calculate performance metrics
calc_metrics <- function(actual, pred) {
  rmse <- rmse(pred, actual)
  mae <- mae(pred, actual)
  mape <- MAPE(pred, actual)
  smape <- sMAPE(pred, actual)
  return(list(RMSE = rmse, MAE = mae, MAPE = mape, sMAPE = smape))
}

# Calculate and print the performance metrics
metrics <- calc_metrics(test_output, pred_output)
print(metrics)

df <- data.frame(test_output = test_output, predicted = pred_output)

# plot the data
ggplot(df, aes(x = test_output, y = predicted)) +
  geom_point() +
  geom_abline(slope = 1, intercept = 0, color = "red") +
  labs(x = "Test Output", y = "Predicted Value", title = "Test Outputs vs Predicted Values")

