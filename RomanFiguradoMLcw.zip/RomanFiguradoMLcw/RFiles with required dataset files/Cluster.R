# import necessary libraries
library(readxl)
library(NbClust)
library(MASS)
library(factoextra)
library(dplyr)
library(cluster)
library(caret)
library(fpc)

vehicle_Data <- read_excel("C://Users//LENOVO//Documents//ML CW//vehicles.xlsx")
vehicle_dataframe <- data.frame(vehicle_Data)#Creates a new data frame called "vehicle_dataframe" by converting the "vehicle_Data" data frame into a data frame using the "data.frame()" function.
vehicle_dataframe <- subset(vehicle_dataframe, select = -1)#Removes the first column (column 1) from the "vehicle_dataframe" using the "subset()" function. This is done by specifying the "select" parameter as "-1", which means to select all columns except the first column.
vehicle_dataframe <- na.omit(vehicle_dataframe)#Removes any rows with missing values from the "vehicle_dataframe" using the "na.omit()" function. This is done to ensure that the data is clean and free of missing values.
column_names <- names(vehicle_dataframe)#Stores the column names of the "vehicle_dataframe" in a variable called "column_names" using the "names()" function.


#--------------------------------------------- part A----------------------------------#
#: Data preprocessing
par(mar=c(5, 5, 2, 1), oma = c(0, 0, 2, 0), cex = 1.2, cex.lab = 1.2, cex.axis = 1.2)
par(bg = "lightgray")
par(mfrow = c(3, 6))

# set custom colors for the box and whiskers
box_col <- "#0072B2"
whisker_col <- "#E69F00"

for (i in seq_len(ncol(vehicle_dataframe)-1)){#show with outliers
  boxplot(vehicle_dataframe[i],
          main = column_names[i],
          col = box_col,
          border = box_col,
          whisklty = 1,
          whiskcol = whisker_col,
          ylab = "Value",
          xlab = "",
          cex.main = 1.5,
          cex.lab = 1.2,
          cex.axis = 1.2)
}


for (i in seq_len(ncol(vehicle_dataframe)-1)) {#remove the outliers
  stats <- boxplot.stats(vehicle_dataframe[, i], coef = 1.5)$stats
  lower_bound <- stats[1]
  upper_bound <- stats[5]
  vehicle_dataframe  <- vehicle_dataframe[!(vehicle_dataframe[, i] < lower_bound | vehicle_dataframe[, i] > upper_bound), ]
}

# Data preprocessing
par(mar=c(5, 5, 2, 1), oma = c(0, 0, 2, 0), cex = 1.2, cex.lab = 1.2, cex.axis = 1.2)
par(bg = "lightgray")
par(mfrow = c(3, 6))

# set custom colors for the box and whiskers
box_col <- "#0072B2"
whisker_col <- "#E69F00"

for (i in seq_len(ncol(vehicle_dataframe)-1)){
  boxplot(vehicle_dataframe[i],#used to show without the outliers
          main = column_names[i],
          col = box_col,
          border = box_col,
          whisklty = 1,
          whiskcol = whisker_col,
          ylab = "Value",
          xlab = "",
          cex.main = 1.5,
          cex.lab = 1.2,
          cex.axis = 1.2)
}

scaled_dataframe <- as.data.frame(scale(vehicle_dataframe[,-ncol(vehicle_dataframe)]))

for (i in seq_len(ncol(scaled_dataframe))){#Repeats the plotting of boxplots for each variable in the modified data frame "vehicle_dataframe". This time, the data is first standardized using the "scale()" function to ensure that all variables have the same scale and mean value.
  boxplot(scaled_dataframe[i],
          main = column_names[i],
          col = box_col,
          border = box_col,
          whisklty = 1,
          whiskcol = whisker_col,
          ylab = "Value",
          xlab = "",
          cex.main = 1.5,
          cex.lab = 1.2,
          cex.axis = 1.2)
}

summary <- summary(scaled_dataframe)#Computes a summary of the scaled data using the "summary()" function and writes the results to a text file named "summary.txt" using the "writeLines()" function

writeLines(capture.output(summary), "summary.txt")

#-------------------------------------------- part B------------------------------------------------------#
# find the best number of cluster centers using the Nbclust, Elbow, Gap statistic, Silhouette Methods
nb_clusters_eucledian <- NbClust(scaled_dataframe, distance = "euclidean", min.nc = 2, max.nc = 10, method = "kmeans")
nb_clusters_manhattan <- NbClust(scaled_dataframe, distance = "manhattan", min.nc = 2, max.nc = 10, method = "kmeans")
nb_clusters_maximum <- NbClust(scaled_dataframe, distance = "maximum", min.nc = 2, max.nc = 10, method = "kmeans")

fviz_nbclust(scaled_dataframe, kmeans, method = "wss") +
geom_vline(xintercept = 3, linetype = 2)+
labs(subtitle = "Elbow method")

fviz_nbclust(scaled_dataframe, kmeans, nstart = 25,  method = "gap_stat", nboot = 500)+
labs(subtitle = "Gap statistic method")

fviz_nbclust(scaled_dataframe, kmeans, method = "silhouette")+
  labs(subtitle = "Silhouette method")

#----------------------------------------part C--------------------------------------------------#
# add class column to scaled data frame
scaled_dataframe$class <- vehicle_dataframe$Class
# clustering when k = 2
k_means_2 <- kmeans(scaled_dataframe[,-ncol(scaled_dataframe)], 2, nstart = 25)
set.seed(5005)
fviz_cluster(k_means_2, data = scaled_dataframe[,-ncol(scaled_dataframe)],
             palette = c("#2E9FDF", "#00AFBB", "#E7B800", "#B800E7"),
             geom = "point",
             ellipse.type = "convex",
             ggtheme = theme_bw()
)
# Output k-means results
k_means_2$centers  # display the centroids for each cluster
k_means_2$cluster  # display the cluster assignments for each observation
k_means_2$betweenss / k_means_2$totss  # display the BSS/TSS ratio

# Calculate BSS and WSS indices
wss <- k_means_2$withinss
bss <- k_means_2$betweenss
tss <- k_means_2$totss
cat("WSS:", round(wss, 2), "\n")
cat("BSS:", round(bss, 2), "\n")
cat("TSS:", round(tss, 2), "\n")

# evaluating performance of the custering algorithem

# clustering when k = 3
set.seed(5005)
k_means_3 <- kmeans(scaled_dataframe[,-ncol(scaled_dataframe)], 3, nstart = 25)

fviz_cluster(k_means_3, data = scaled_dataframe[,-ncol(scaled_dataframe)],
             palette = c("#2E9FDF", "#00AFBB", "#E7B800", "#B800E7"),
             geom = "point",
             ellipse.type = "convex",
             ggtheme = theme_bw()
)

# Output k-means results
k_means_3$centers  # display the centroids for each cluster
k_means_3$cluster  # display the cluster assignments for each observation
k_means_3$betweenss / k_means_3$totss  # display the BSS/TSS ratio

# Calculate BSS and WSS indices
wss3 <- k_means_3$tot.withinss
bss3 <- k_means_3$betweenss
tss3 <- k_means_3$totss
cat("WSS:", round(wss3, 2), "\n")
cat("BSS:", round(bss3, 2), "\n")
cat("TSS:", round(tss3, 2), "\n")

# clustering when k = 4
set.seed(5005)
k_means_4 <- kmeans(scaled_dataframe[,-ncol(scaled_dataframe)], 4, nstart = 25)

fviz_cluster(k_means_4, data = scaled_dataframe[,-ncol(scaled_dataframe)],
             palette = c("#2E9FDF", "#00AFBB", "#E7B800", "#B800E7"),
             geom = "point",
             ellipse.type = "convex",
             ggtheme = theme_bw()
)
# Output k-means results
k_means_4$centers  # display the centroids for each cluster
k_means_4$cluster  # display the cluster assignments for each observation
k_means_4$betweenss / k_means_4$totss  # display the BSS/TSS ratio

# Calculate BSS and WSS indices
wss4 <- k_means_4$tot.withinss
bss4 <- k_means_4$betweenss
tss4 <- k_means_4$totss
cat("WSS:", round(wss4, 2), "\n")
cat("BSS:", round(bss4, 2), "\n")
cat("TSS:", round(tss4, 2), "\n")

#------------------------------------ part D---------------------------------------#
# when k = 2
# Generate silhouette plot
silhouette2 <- silhouette(k_means_2$cluster, dist(scaled_dataframe))
fviz_silhouette(silhouette2)
avg_silhouette_width2 <- mean(silhouette2[,3])
cat("Average silhouette width score:", round(avg_silhouette_width2, 2), "\n")

#when k = 3
silhouette3 <- silhouette(k_means_3$cluster, dist(scaled_dataframe))
fviz_silhouette(silhouette3)
avg_silhouette_width3 <- mean(silhouette3[,3])
cat("Average silhouette width score:", round(avg_silhouette_width3, 2), "\n")

#when k = 4
silhouette4 <- silhouette(k_means_4$cluster, dist(scaled_dataframe))
fviz_silhouette(silhouette4)
avg_silhouette_width4 <- mean(silhouette4[,3])
cat("Average silhouette width score:", round(avg_silhouette_width4, 2), "\n")

#------------------------------------------part E-----------------------------------------------------------#
# Compute variance of each variable
vars <- apply(vehicle_dataframe[,-ncol(vehicle_dataframe)], 2, var)

# Apply PCA using prcomp()
pca <- prcomp(vehicle_dataframe[,-ncol(vehicle_dataframe)], center = TRUE, scale = TRUE)
pca_summary <- summary(pca, loadings = TRUE)

# Extract the eigenvalues and eigenvectors
eigenvalues <- pca$sdev^2
eigenvectors <- data.frame(pca$rotation)

# Extract the cumulative proportion values
prop_var <- cumsum(pca_summary$importance[2,])

# Plot scree plot to determine the number of principal components to keep
plot(prop_var, type = "b", xlab = "Principal Component", ylab = "Cumulative Proportion of Variance Explained", main = "Scree Plot")
abline(h = 0.92, lty = 2)

# Choose the first n principal components that provide at least 92% cumulative variance
n <- min(which(prop_var >= 0.92))

# Create transformed dataset with selected principal components
transformed <- data.frame(pca$x[, 1:n])

#---------------------------------part F ---------------------------------------------#
set.seed(1002)
nb_clusters_eucledian <- NbClust(transformed, distance = "euclidean", min.nc = 2, max.nc = 10, method = "kmeans", index = "all")
nb_clusters_manhattan <- NbClust(transformed, distance = "manhattan", min.nc = 2, max.nc = 10, method = "kmeans", index = "all")
nb_clusters_maximum <- NbClust(transformed, distance = "maximum", min.nc = 2, max.nc = 10, method = "kmeans", index = "all")

fviz_nbclust(transformed, kmeans, method = "wss") +
geom_vline(xintercept = 3, linetype = 2)+
labs(subtitle = "Elbow method PCA")

fviz_nbclust(transformed, kmeans, nstart = 25,  method = "gap_stat", nboot = 100)+
labs(subtitle = "Gap statistic method PCA")

fviz_nbclust(transformed, kmeans, method = "silhouette")+
  labs(subtitle = "Silhouette method PCA")

#------------------------------------part G------------------------------------------#
# Perform k-means clustering on transformed dataset
set.seed(1002)
kmeans_vehicle_pca <- kmeans(transformed, centers = 3, nstart = 25)
fviz_cluster(kmeans_vehicle_pca, data = transformed,
             palette = c("#2E9FDF", "#00AFBB", "#E7B800", "#B800E7"),
             geom = "point",
             ellipse.type = "convex",
             ggtheme = theme_bw()
)
# Print k-means results
kmeans_vehicle_pca

# Calculate within-cluster sum of squares (WSS), between sum of squares (BSS), and total sum of squares (TSS)
wss_pca <- kmeans_vehicle_pca$tot.withinss
bss_pca <- kmeans_vehicle_pca$betweenss
tss_pca <- kmeans_vehicle_pca$totss

# Print WSS, BSS, and TSS values
sprintf("Within-cluster sum of squares: %.2f", wss)
sprintf("Between sum of squares: %.2f", bss)
sprintf("Total sum of squares: %.2f", tss)

# Print cluster centers
kmeans_vehicle_pca$centers
#-------------------------------------part H-----------------------------------#
sil_pca <- silhouette(kmeans_vehicle_pca$cluster, dist(transformed))
fviz_silhouette(sil_pca)

#-------------------------------------part I------------------------------------#

ch_index <- calinhara(transformed, kmeans_vehicle_pca$cluster)
sprintf("Calinski-Harabasz Index = %.2f", ch_index)

# Calculate the silhouette plot and print the average silhouette width score
sil_pca <- silhouette(kmeans_vehicle_pca$cluster, dist(transformed))
avg_sil_width <- mean(sil_pca[, 3])
fviz_silhouette(sil_pca)
sprintf("Average silhouette width: %.2f", avg_sil_width)




































